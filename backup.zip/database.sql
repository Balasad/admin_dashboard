CREATE DATABASE classified_ads;
USE classified_ads;

CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    parent_id INT NULL,
    slug VARCHAR(100) NOT NULL,
    icon VARCHAR(10) DEFAULT '📦',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_parent (parent_id)
);

CREATE TABLE brands (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_category (category_id)
);

CREATE TABLE models (
    id INT PRIMARY KEY AUTO_INCREMENT,
    brand_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE,
    INDEX idx_brand (brand_id)
);

CREATE TABLE category_fields (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    field_type ENUM('text', 'number', 'dropdown', 'textarea', 'brand_dropdown', 'model_dropdown') DEFAULT 'text',
    is_mandatory BOOLEAN DEFAULT FALSE,
    dropdown_options TEXT NULL,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    seller_id INT NULL,
    category_id INT NOT NULL,
    brand_id INT NULL,
    model_id INT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2),
    location VARCHAR(100),
    user_name VARCHAR(100),
    user_phone VARCHAR(20),
    user_email VARCHAR(100),
    status ENUM('active', 'sold', 'inactive') DEFAULT 'active',
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE SET NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (brand_id) REFERENCES brands(id),
    FOREIGN KEY (model_id) REFERENCES models(id)
);

CREATE TABLE product_field_values (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    field_id INT NOT NULL,
    field_value TEXT,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (field_id) REFERENCES category_fields(id) ON DELETE CASCADE
);

CREATE TABLE admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sellers table
CREATE TABLE sellers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    location VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample Data
INSERT INTO categories (name, parent_id, slug, icon) VALUES 
('Electronics', NULL, 'electronics', '📱'),
('Mobiles', 1, 'mobiles', '📱'),
('Smartphones', 2, 'smartphones', '📱'),
('Feature Phones', 2, 'feature-phones', '📞'),
('Laptops', 1, 'laptops', '💻'),
('Cars', NULL, 'cars', '🚗'),
('Sedan', 6, 'sedan', '🚗'),
('SUV', 6, 'suv', '🚙'),
('Furniture', NULL, 'furniture', '🛋️');

INSERT INTO brands (category_id, name) VALUES
(2, 'Samsung'), (2, 'Apple'), (2, 'OnePlus'), (2, 'Xiaomi'), (2, 'Realme'), (2, 'Vivo'), (2, 'Oppo'), (2, 'Google'),
(5, 'Dell'), (5, 'HP'), (5, 'Lenovo'), (5, 'Apple'), (5, 'Asus'), (5, 'Acer'),
(6, 'Maruti Suzuki'), (6, 'Hyundai'), (6, 'Tata'), (6, 'Honda'), (6, 'Mahindra'), (6, 'Toyota');

INSERT INTO models (brand_id, name) VALUES
(1, 'Galaxy S24 Ultra'), (1, 'Galaxy S24'), (1, 'Galaxy S23 FE'), (1, 'Galaxy A54'), (1, 'Galaxy M34'),
(2, 'iPhone 15 Pro Max'), (2, 'iPhone 15 Pro'), (2, 'iPhone 15'), (2, 'iPhone 14'), (2, 'iPhone 13'), (2, 'iPhone SE'),
(3, 'OnePlus 12'), (3, 'OnePlus 11'), (3, 'OnePlus Nord 3'),
(9, 'XPS 13'), (9, 'XPS 15'), (9, 'Inspiron 15'), (9, 'Alienware m15'),
(12, 'MacBook Pro 14"'), (12, 'MacBook Pro 16"'), (12, 'MacBook Air M2'), (12, 'MacBook Air M1');

INSERT INTO category_fields (category_id, field_name, field_type, is_mandatory, dropdown_options, display_order) VALUES
(1, 'Condition', 'dropdown', 1, '["Brand New", "Like New", "Good", "Fair", "Used"]', 1),
(1, 'Warranty Available', 'dropdown', 0, '["Yes", "No"]', 2),
(2, 'Brand', 'brand_dropdown', 1, NULL, 1),
(2, 'Model', 'model_dropdown', 1, NULL, 2),
(2, 'RAM', 'dropdown', 1, '["2GB", "3GB", "4GB", "6GB", "8GB", "12GB", "16GB"]', 3),
(2, 'Storage', 'dropdown', 1, '["32GB", "64GB", "128GB", "256GB", "512GB", "1TB"]', 4),
(2, 'Color', 'dropdown', 1, '["Black", "White", "Blue", "Green", "Red", "Gold", "Silver", "Purple"]', 5),
(2, 'Battery Capacity', 'dropdown', 0, '["3000-4000mAh", "4000-5000mAh", "5000-6000mAh", "6000mAh+"]', 6),
(3, 'Operating System', 'dropdown', 1, '["Android", "iOS"]', 1),
(3, 'Screen Size', 'dropdown', 1, '["5.5-6.0\"", "6.0-6.5\"", "6.5-7.0\"", "7.0+"]', 2),
(3, 'Camera', 'dropdown', 1, '["12MP", "48MP", "50MP", "64MP", "108MP", "200MP"]', 3),
(3, '5G Support', 'dropdown', 1, '["Yes", "No"]', 4),
(5, 'Brand', 'brand_dropdown', 1, NULL, 1),
(5, 'Model', 'model_dropdown', 1, NULL, 2),
(5, 'Processor', 'dropdown', 1, '["Intel Core i3", "Intel Core i5", "Intel Core i7", "Intel Core i9", "AMD Ryzen 5", "AMD Ryzen 7", "Apple M1", "Apple M2"]', 3),
(5, 'RAM', 'dropdown', 1, '["4GB", "8GB", "16GB", "32GB", "64GB"]', 4),
(5, 'Storage Type', 'dropdown', 1, '["HDD", "SSD", "SSD + HDD"]', 5),
(5, 'Storage Capacity', 'dropdown', 1, '["256GB", "512GB", "1TB", "2TB"]', 6),
(5, 'Screen Size', 'dropdown', 1, '["13\"", "14\"", "15.6\"", "17\""]', 7),
(6, 'Brand', 'brand_dropdown', 1, NULL, 1),
(6, 'Year', 'dropdown', 1, '["2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017"]', 2),
(6, 'Fuel Type', 'dropdown', 1, '["Petrol", "Diesel", "CNG", "Electric", "Hybrid"]', 3),
(6, 'Transmission', 'dropdown', 1, '["Manual", "Automatic", "AMT", "CVT"]', 4),
(6, 'Kilometers Driven', 'dropdown', 1, '["0-10,000", "10,000-25,000", "25,000-50,000", "50,000-75,000", "75,000-1,00,000", "1,00,000+"]', 5),
(6, 'Owners', 'dropdown', 1, '["1st Owner", "2nd Owner", "3rd Owner", "4th+ Owner"]', 6);
