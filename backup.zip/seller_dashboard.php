<?php
require_once 'config.php';

// Check if seller is logged in
if (!isset($_SESSION['seller_id'])) {
    header('Location: seller_login.php');
    exit;
}

$conn = getDBConnection();
$seller_id = $_SESSION['seller_id'];

// Get seller info
$stmt = $conn->prepare("SELECT * FROM sellers WHERE id = ?");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$seller = $stmt->get_result()->fetch_assoc();

// Handle status update
if (isset($_POST['update_status'])) {
    $product_id = intval($_POST['product_id']);
    $status = $_POST['status'];
    
    $stmt = $conn->prepare("UPDATE products SET status = ? WHERE id = ? AND seller_id = ?");
    $stmt->bind_param("sii", $status, $product_id, $seller_id);
    $stmt->execute();
    
    header('Location: seller_dashboard.php?updated=1');
    exit;
}

// Handle delete
if (isset($_POST['delete_product'])) {
    $product_id = intval($_POST['product_id']);
    
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ? AND seller_id = ?");
    $stmt->bind_param("ii", $product_id, $seller_id);
    $stmt->execute();
    
    header('Location: seller_dashboard.php?deleted=1');
    exit;
}

// Get seller's products with category info
$stmt = $conn->prepare("SELECT p.*, c.name as category_name, c.icon as category_icon,
                        b.name as brand_name, m.name as model_name
                        FROM products p
                        LEFT JOIN categories c ON p.category_id = c.id
                        LEFT JOIN brands b ON p.brand_id = b.id
                        LEFT JOIN models m ON p.model_id = m.id
                        WHERE p.seller_id = ?
                        ORDER BY p.created_at DESC");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$products = $stmt->get_result();

// Get statistics
$stmt = $conn->prepare("SELECT 
                        COUNT(*) as total_ads,
                        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_ads,
                        SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END) as sold_ads,
                        SUM(views) as total_views
                        FROM products WHERE seller_id = ?");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - Seller Portal</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
        
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-icon { width: 50px; height: 50px; background: rgba(255,255,255,0.2); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; }
        h1 { font-size: 28px; }
        .header-right { display: flex; align-items: center; gap: 20px; }
        .user-info { background: rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 50px; }
        .btn-logout { background: rgba(255,255,255,0.3); padding: 10px 20px; border: 2px solid white; border-radius: 50px; text-decoration: none; color: white; font-weight: 600; transition: all 0.3s; }
        .btn-logout:hover { background: white; color: #667eea; }
        
        .container { max-width: 1400px; margin: 30px auto; padding: 0 30px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; transition: all 0.3s; }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 6px 25px rgba(0,0,0,0.15); }
        .stat-icon { font-size: 48px; margin-bottom: 15px; }
        .stat-value { font-size: 36px; font-weight: 700; color: #333; margin-bottom: 5px; }
        .stat-label { color: #666; font-size: 14px; font-weight: 600; }
        
        .action-bar { background: white; padding: 20px 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
        .btn-post { background: linear-gradient(135deg, #56ab2f 0%, #a8e063 100%); color: white; padding: 15px 30px; border-radius: 50px; text-decoration: none; font-weight: 700; transition: all 0.3s; display: inline-flex; align-items: center; gap: 10px; font-size: 16px; }
        .btn-post:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(86, 171, 47, 0.4); }
        
        .success { background: linear-gradient(135deg, #56ab2f 0%, #a8e063 100%); color: white; padding: 20px; border-radius: 15px; margin-bottom: 20px; display: flex; align-items: center; gap: 15px; font-weight: 600; }
        
        .products-section { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .section-title { font-size: 24px; font-weight: 700; margin-bottom: 25px; color: #333; }
        
        .product-card { background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); padding: 25px; border-radius: 12px; margin-bottom: 20px; display: grid; grid-template-columns: 100px 1fr auto; gap: 25px; align-items: center; transition: all 0.3s; }
        .product-card:hover { transform: translateX(5px); box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .product-image { width: 100px; height: 100px; background: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 48px; }
        .product-info h3 { font-size: 20px; color: #333; margin-bottom: 8px; }
        .product-meta { display: flex; gap: 15px; flex-wrap: wrap; margin-top: 10px; }
        .meta-badge { background: white; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; color: #666; }
        .product-actions { display: flex; flex-direction: column; gap: 10px; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; transition: all 0.3s; text-decoration: none; text-align: center; }
        .btn-edit { background: #ffa726; color: white; }
        .btn-status { background: #667eea; color: white; }
        .btn-delete { background: #f45c43; color: white; }
        .btn:hover { transform: scale(1.05); }
        
        .status-badge { padding: 8px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; }
        .status-active { background: #d4edda; color: #155724; }
        .status-sold { background: #cce5ff; color: #004085; }
        .status-inactive { background: #f8d7da; color: #721c24; }
        
        .empty-state { text-align: center; padding: 80px 20px; color: #999; }
        .empty-icon { font-size: 80px; margin-bottom: 20px; }
        
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .product-card { grid-template-columns: 1fr; text-align: center; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="logo-section">
                <div class="logo-icon">🛒</div>
                <div>
                    <h1>Seller Dashboard</h1>
                    <p style="opacity: 0.9; font-size: 14px;">Manage Your Listings</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">👤 <?php echo htmlspecialchars($seller['name']); ?></div>
                <a href="seller_logout.php" class="btn-logout">Logout</a>
            </div>
        </div>
    </div>
    
    <div class="container">
        <?php if (isset($_GET['updated'])): ?>
            <div class="success">
                <span style="font-size: 32px;">✅</span>
                <span>Product updated successfully!</span>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['deleted'])): ?>
            <div class="success">
                <span style="font-size: 32px;">✅</span>
                <span>Product deleted successfully!</span>
            </div>
        <?php endif; ?>
        
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-value"><?php echo $stats['total_ads']; ?></div>
                <div class="stat-label">Total Ads</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-value"><?php echo $stats['active_ads']; ?></div>
                <div class="stat-label">Active Ads</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-value"><?php echo $stats['sold_ads']; ?></div>
                <div class="stat-label">Sold Items</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👁️</div>
                <div class="stat-value"><?php echo number_format($stats['total_views']); ?></div>
                <div class="stat-label">Total Views</div>
            </div>
        </div>
        
        <!-- Action Bar -->
        <div class="action-bar">
            <h2>My Listings</h2>
            <a href="crud/product_edit.php?id=<?php echo $product['id']; ?>" class="btn btn-edit">✏️ Edit</a>
                <span style="font-size: 24px;">+</span>
                <a href="post_ad.php" class="btn-post" style="margin-top: 20px;">Post Your Ad</a>
            </a>
        </div>
        
        <!-- Products List -->
        <div class="products-section">
            <?php if ($products->num_rows == 0): ?>
                <div class="empty-state">
                    <div class="empty-icon">📦</div>
                    <h3>No ads posted yet</h3>
                    <p>Start selling by posting your first ad!</p>
                    <a href="seller_post_ad.php" class="btn-post" style="margin-top: 20px;">Post Your First Ad</a>
                </div>
            <?php else: ?>
                <?php while ($product = $products->fetch_assoc()): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php echo $product['category_icon'] ?: '📦'; ?>
                        </div>
                        
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($product['title']); ?></h3>
                            <div style="font-size: 24px; font-weight: 700; color: #667eea; margin: 10px 0;">
                                ₹<?php echo number_format($product['price'], 2); ?>
                            </div>
                            <div class="product-meta">
                                <span class="meta-badge"><?php echo $product['category_name']; ?></span>
                                <?php if ($product['brand_name']): ?>
                                    <span class="meta-badge"><?php echo $product['brand_name']; ?></span>
                                <?php endif; ?>
                                <?php if ($product['model_name']): ?>
                                    <span class="meta-badge"><?php echo $product['model_name']; ?></span>
                                <?php endif; ?>
                                <span class="meta-badge">📍 <?php echo htmlspecialchars($product['location']); ?></span>
                                <span class="meta-badge">👁️ <?php echo $product['views']; ?> views</span>
                                <span class="meta-badge">📅 <?php echo date('M d, Y', strtotime($product['created_at'])); ?></span>
                            </div>
                            <div style="margin-top: 10px;">
                                <span class="status-badge status-<?php echo $product['status']; ?>">
                                    <?php echo strtoupper($product['status']); ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="product-actions">
                            <a href="crud/product_edit.php?id=<?php echo $product['id']; ?>" class="btn btn-edit">✏️ Edit</a>
                            <form method="POST" style="margin: 0;">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <select name="status" onchange="this.form.submit()" class="btn btn-status" style="width: 100%;">
                                    <option value="active" <?php echo $product['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="sold" <?php echo $product['status'] == 'sold' ? 'selected' : ''; ?>>Sold</option>
                                    <option value="inactive" <?php echo $product['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                            
                            <form method="POST" onsubmit="return confirm('Delete this ad?')" style="margin: 0;">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="delete_product" class="btn btn-delete">🗑️ Delete</button>
                            </form>
                        </div> 
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
